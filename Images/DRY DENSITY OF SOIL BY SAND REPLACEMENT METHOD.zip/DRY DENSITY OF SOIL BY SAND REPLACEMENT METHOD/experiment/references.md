<table style="text-align:justify;">
  <tr style="background-color:transparent;">
    <th style="width:65%;">References</th>
    <th style="width:35%;">Contributors list</th>
  </tr>
  <tr style="background-color:transparent;">
    <td  style="width:65%;">
    1. IS 3025 (Part 15)- 1984: Method of Sampling and Test (Physical and Chemical) for Water and Wastewater : Total Residue (total Solids, Dissolved and Suspended, First Revision.</br></br>
    2. American Public Health Association et al, Standard Methods for the Examinations of Water and Waste Water, APHA. 1998.</br></br>
    3. Sawyer, C. N., McCarty, P. L., and Parkin, G. F. 2000. Chemistry for Environmental Engineering. Fourth Edition, McGraw-Hill, Inc., New York.</td>
    <td style="width:35%;">Developer : Dr. Pruthviraj U | NITK</br></br>
    Contributors :
    <ul style="list-style-type: none;">
    <li>Anusha B Salian | NITK</li>
    <li>Swathi Shetty | NITK</li>
    <li>Aishwarya Shetty | NITK</li>
    <li>Aishwarya Hegde | NITK</li>
    <li>Gautam Anand (17CV213) | NITK</li>
    <li>Ravi Kumar Rahul (17CV136) | NITK</li>
    <li>Sandesh Mantri (17CV222) | NITK</li>
    </ul></td>
  </tr>
</table>

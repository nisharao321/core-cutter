## <b> Pre-test</b>
#### Please attempt the following questions

<br>
Q 1. Fine suspended solid in water is removed by <br>
a. Screening <br>
b. Skimming<br>
<b>c. Sedimentation</b><br>
d. Filtration<br> <br>

Q 2. Total Suspended Solids are mostly responsible for <br>
a. Colour<br></b>
<b>b. Turbidity</b><br>
c. Odour<br>
d. Taste<br>

Q 3. Always the Total Suspended Solids value will be <br>
a. Less than Total Dissolved Solids<br>
b. Greater than Total Dissolved Solids<br>
<b>c. Less than Total Solids</b><br>
d. Greater than Total Solids<br>

Q 4. The chemical substance used in the desiccators is _____________________________ <br>
a. Calcium Carbonate<br>
b. Sodium Chloride<br>
c. Sodium Hydroxide<br>
<b>d. Calcium Chloride</b><br>

Q 5. High total dissolved solids indicates lower level of hardness <br>
a. True<br>
<b>b. False</b><br>

To determine Total Solids (TS), Total Dissolved Solids (TDS), Total Suspended Solids (TSS), Volatile Suspended Solids (VSS) and Fixed Suspended Solids (FSS) in the given water sample. 

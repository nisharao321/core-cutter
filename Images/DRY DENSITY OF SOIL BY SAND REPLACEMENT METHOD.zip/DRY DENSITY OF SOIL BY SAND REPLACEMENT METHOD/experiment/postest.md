## Post test
<br>
Q 1. The concentration of dissolved solids in water can be determined by Specific conductance. <br>
a. False<br>
<b>b. True</b><br><br>

Q 2. The settleable suspended solids with diameter 0.15 to 0.2mm are generally <br>
<b>a. Inorganic</b><br>
b. Organic<br>
c. Algae<br>
d. Fungi<br>

Q 3. The dissolved solids that impose BOD are _________________ <br>
a. Non-volatile solids<br>
b. Total solids<br></b>
c. Inorganic solids<br>
<b>d. Volatile solids</b><br>

Q 4. As per IS Code the acceptable TDS value is <br>
a. 250ppm<br>
b. 750ppm<br>
<b>c. 500ppm</b><br>
d. 900ppm<br>

Q 5. The presence of high total solids in water changes the colour and taste of water. <br>
<b>a. False</b><br>
b. True<br>

## Storyboard (Round 2)

Experiment 2: Determination of TS,TDS and TSS in Water

### 1. Story Outline